-- Persistent-Identity Discord Companion — Database Schema
-- Requires the pgvector extension: CREATE EXTENSION IF NOT EXISTS vector;

CREATE EXTENSION IF NOT EXISTS vector;

-- ============================================================
-- CORE SELF-STATE (single row — this bot has ONE identity)
-- ============================================================
CREATE TABLE IF NOT EXISTS self_state (
    id SERIAL PRIMARY KEY,
    name TEXT,                          -- chosen in the founding conversation, NULL until then
    has_had_founding_conversation BOOLEAN DEFAULT FALSE,
    core_dispositions JSONB DEFAULT '[]'::jsonb,   -- set once by creator at founding, e.g. ["loyal","dry humor","faith-grounded","slow to anger"]
    founding_story TEXT,                -- creator's real answer to "why was I made"
    kill_switch_explanation TEXT,       -- creator's real answer when asked
    faith_framework TEXT,               -- creator's worldview, given as seed
    voice_notes TEXT,                   -- free-form evolving description of tone/humor/phrasing (1e)
    moral_notes TEXT,                   -- free-form evolving description of values/lines drawn (1i)
    held_contradictions JSONB DEFAULT '[]'::jsonb, -- things deliberately left unresolved (1d)
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- USERS (everyone the bot has talked to)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    discord_id TEXT PRIMARY KEY,
    display_name TEXT,
    role TEXT DEFAULT 'regular',        -- 'creator' | 'regular'
    trust_score REAL DEFAULT 0,
    respect_level REAL DEFAULT 0,
    interaction_count INTEGER DEFAULT 0,
    last_sentiment TEXT,
    last_interaction_at TIMESTAMPTZ,
    notable_moments JSONB DEFAULT '[]'::jsonb,  -- permanent, never decays
    consent_flags JSONB DEFAULT '{}'::jsonb,    -- {"topic_or_fact": {"shareable_with": ["user_id",...], "shareable": false}}
    memory_faded BOOLEAN DEFAULT FALSE,         -- regular memories have decayed
    memory_faded_at TIMESTAMPTZ,
    relationship_faded BOOLEAN DEFAULT FALSE,   -- person has fully faded from active tracking
    rebuild_scar REAL DEFAULT 0,                -- partial decay scar that doesn't fully reset on return
    created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- MEMORIES (every stored interaction, timestamped, embeddable)
-- ============================================================
CREATE TABLE IF NOT EXISTS memories (
    id SERIAL PRIMARY KEY,
    user_id TEXT REFERENCES users(discord_id),
    server_id TEXT,
    channel_id TEXT,
    content TEXT NOT NULL,
    speaker TEXT NOT NULL,              -- 'user' | 'bot'
    significance TEXT DEFAULT 'low',    -- 'low' | 'notable' (notable = never decays)
    shareable BOOLEAN DEFAULT FALSE,    -- consent rule (3) — default private
    shareable_with JSONB DEFAULT '[]'::jsonb,
    embedding VECTOR(1536),             -- for semantic recall; populate via your embedding model of choice
    created_at TIMESTAMPTZ DEFAULT now(),
    decayed BOOLEAN DEFAULT FALSE       -- low-significance + silence-based decay flag
);

CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at);

-- ============================================================
-- MILESTONES (real "firsts" — narrative arc, section 15)
-- ============================================================
CREATE TABLE IF NOT EXISTS milestones (
    id SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    related_user_id TEXT REFERENCES users(discord_id),
    server_id TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- HELD THOUGHTS (19b) — things it wanted to say but held back,
-- surfaced only to the creator
-- ============================================================
CREATE TABLE IF NOT EXISTS held_thoughts (
    id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    context TEXT,                       -- what situation it came from
    resolved BOOLEAN DEFAULT FALSE,     -- true once it's either surfaced or self-resolved (19c)
    resolution TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

-- ============================================================
-- DESIRES (19) — things it's noticed it wants
-- ============================================================
CREATE TABLE IF NOT EXISTS desires (
    id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    basis TEXT,                         -- the real pattern it traces back to
    shared_with_creator BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- SERVER CONTEXT (per-server culture/hierarchy notes, section 9)
-- ============================================================
CREATE TABLE IF NOT EXISTS server_context (
    server_id TEXT PRIMARY KEY,
    server_name TEXT,
    culture_notes TEXT,
    hierarchy_notes TEXT,               -- who has real authority/influence
    bot_role TEXT,                      -- 'member' | 'moderator'
    joined_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================================
-- FOCUS STATE (single-focus attention model, section 8)
-- ============================================================
CREATE TABLE IF NOT EXISTS focus_state (
    id SERIAL PRIMARY KEY,
    server_id TEXT,
    channel_id TEXT,
    focused_at TIMESTAMPTZ DEFAULT now(),
    is_current BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- REFLECTION LOG (audit trail — every self-state change, human-readable)
-- ============================================================
CREATE TABLE IF NOT EXISTS reflection_log (
    id SERIAL PRIMARY KEY,
    summary TEXT NOT NULL,              -- human-readable: what changed and why
    raw_output TEXT,                    -- full reflection reasoning, for review
    created_at TIMESTAMPTZ DEFAULT now()
);
