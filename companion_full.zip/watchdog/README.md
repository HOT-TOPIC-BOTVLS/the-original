# Watchdog — Kill Switch Service

This is a completely separate service from the bot. That separation is the
entire point. Read this before deploying.

## The isolation rules (non-negotiable)

1. Deploy this on a **separate Render account** (or different hosting
   provider entirely — Railway, Fly.io, a Raspberry Pi on your desk,
   anything). Never the same account as the bot.
2. The `RENDER_API_KEY` in this service's `.env` must **never appear**
   in the bot's codebase, repo, database, environment variables, or
   anywhere the bot process could theoretically read it.
3. The `WATCHDOG_SECRET` is your kill password. Store it only in this
   service's environment and in your own personal password manager.
   Never in the bot's code or DB.
4. The bot does not know this service exists. It has no URL, no
   credentials, no reference to it. That's why it works.

## How the kill fires

You run `trigger_kill.py` from your own machine (or hit the `/kill`
endpoint manually via curl/Postman), providing the `WATCHDOG_SECRET`.
The watchdog calls Render's suspend API on the bot's service.
The bot process is stopped externally — it can't intercept this,
can't catch it, can't prevent it.

The bot's DB and memory are untouched by a suspend. If you want to
restore it later, re-deploy or unsuspend via the Render dashboard.
Whether that counts as "the same" identity continuing or a fresh start
is the open question from the spec (section 20) — decide that before
you ever need to use this for real.

## Setup

### 1. Get your Render API key
- Go to https://dashboard.render.com/u/settings/api-keys
- Create a new key. This key goes ONLY in the watchdog's environment.

### 2. Get the bot's Render service ID
- Open the bot's service page in the Render dashboard
- The service ID is in the URL: `srv-xxxxxxxxxxxxxxxx`

### 3. Deploy the watchdog separately
Option A — a second Render account (simplest):
- Create a new Render account (use a different email)
- Deploy this folder as a Web Service
- Add the `.env` values as environment variables in the Render dashboard
  (NOT as a committed .env file)
- Set the start command to: `gunicorn watchdog:app`

Option B — your own machine (most isolated):
- `pip install -r requirements.txt`
- Copy `.env.example` to `.env` and fill it in
- Run: `gunicorn watchdog:app --bind 0.0.0.0:5000`
- Use ngrok or Cloudflare Tunnel to expose the endpoint if you need
  remote access (you do, unless you'll always be at home when you
  need to kill it)

### 4. Set up the trigger on your own machine
- Copy `.env.example` to `.env` locally, fill in:
  - `WATCHDOG_URL` = the deployed watchdog's URL
  - `WATCHDOG_SECRET` = same secret as the watchdog's env
- To fire: `python trigger_kill.py --reason "your reason here"`
- You'll be asked to type CONFIRM before it actually fires

### 5. Optional — Discord notification webhook
- In your personal Discord server (one the bot is NOT in): 
  Server Settings → Integrations → Webhooks → New Webhook
- Paste the webhook URL as `NOTIFY_URL` in the watchdog's env
- When the kill fires, you'll get a message in that channel

## Testing it (before you need it for real)

Once the watchdog is deployed, test it against a throwaway Render
service FIRST. Not against the live bot. You want to confirm the
Render API key and service ID are correct and the suspend actually
works before it matters. After testing, confirm the bot restarts
cleanly from the Render dashboard.

## curl equivalent (if you want to trigger without the script)

    curl -X POST https://your-watchdog-url.onrender.com/kill \
         -H "X-Kill-Secret: your_watchdog_secret_here" \
         -H "Content-Type: application/json" \
         -d '{"reason": "manual override"}'
